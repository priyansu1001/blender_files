### Feel free to put your examples using this library in here! Just make a pull request.

Requirements for acception:

* You must put it in the examples folder
* It must work? (Duh.)
* It must have at least some comments to help people understand
* It shouldn't be an example already made

Guidelines for acception:

* You could possibly make the example to work with a specific other program (Ex: spotify presence)
* It shouldn't be too long, the viewers should easily figure out what you're doing fast
* It shouldn't have a ton of dependencies, but a few are fine

And there you go!
