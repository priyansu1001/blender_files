# Dependencies

This directory contains dependencies with the GPL-3.0 license. They are not owned by me and I do not claim any ownership over them.

Please ensure that you comply with the terms and conditions of the GPL-3.0 license when using these dependencies.

1. B\*tt\*rFBX (obfuscation? am I fooling anyone searching for this?)
2. ExpyKit

If for any reason these dependencies have been incorrectly understood to be under the GPL-3.0 license please let me know.
